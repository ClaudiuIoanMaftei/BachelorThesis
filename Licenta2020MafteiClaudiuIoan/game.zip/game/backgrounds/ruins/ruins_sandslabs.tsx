<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="ruins_sandslabs" tilewidth="8" tileheight="9" spacing="2" tilecount="63" columns="21">
 <image source="../../backgrounds/ruins/tileset_sandslab.png" width="208" height="31"/>
</tileset>
