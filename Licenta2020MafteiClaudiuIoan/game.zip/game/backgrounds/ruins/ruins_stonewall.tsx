<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="ruins_stonewall" tilewidth="4" tileheight="4" tilecount="512" columns="32">
 <image source="../../backgrounds/ruins/tileset_stonewall.png" width="128" height="64"/>
</tileset>
